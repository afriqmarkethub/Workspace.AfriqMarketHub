# AMH OS — Internal Publish Ready v13

Private internal operating system for AfriqMarketHub. This is **not a public website**. It is a private AMH workspace for staff, vendors, vendor field staff, couriers, and approved support users.

## What is included

- Internal-only login page
- Secure role PIN login and logout
- Home Office for every role
- Role-based workstations that look independent but work together
- Smart Work Queue / Smart Tasks
- Task notes, comments, collaboration, attachments, print/send actions, approvals concept
- Files & Documents for every role
- Office-file placeholders: Document, Spreadsheet, Presentation, Note, PDF
- Company Facesheet concept for important information sharing
- Staff contact visibility rule: phone, fax, and company email can be hidden/shown, but at least one approved contact method remains visible when contact access is required
- Profile photo and personal motto
- Vendor Field Staff communication area
- Customer Service, Vendor Operations, Logistics, Finance, HR, Marketing/Copywriter workspaces
- AMH Technical Support label for staff-facing bug/maintenance requests
- Third-party company names hidden from normal staff workspaces
- External Partner / Third-Party control in AMH Control/Admin
- Add, deactivate, and replace users, vendor staff, and third-party reps while keeping history
- Audit trail for important activity
- Need-to-know access model: unavailable modules do not appear to the user
- White background, black/charcoal navigation, AMH blue action buttons

## Important design rule

Each role keeps its own **Home Office**. The public website is separate and can continue being maintained by third parties. AMH OS is the internal office where work is assigned, tracked, documented, and audited.

Normal users do not see founder information, executive confidential information, third-party company names, unrelated departments, or any hidden system area. The interface simply shows the office and tools required for their work.

## Demo staff PINs

Role login page: `/ops/login`

- Executive 1: `1001`
- Executive 2: `1002`
- Operations Manager: `2001`
- Delivery & Fulfilment: `3001`
- Customer Care: `4001`
- Copywriter: `5001`
- HR & Admin: `6001`
- Finance: `7001`

You can add or edit roles from the Admin page.

## Admin login

Admin page: `/ops/admin/login`

Default local admin:

- Username: `amhadmin`
- Password: `AMH@2024!`

Before real use, set a new admin password using Replit Secrets or environment variables:

```text
OPS_ADMIN_PASSWORD=your-strong-admin-password
SESSION_SECRET=your-long-random-secret
```

## Run in Replit

1. Upload or import this folder/ZIP into Replit.
2. Replit should detect Python.
3. Open **Secrets** and add:

```text
SESSION_SECRET=change-this-to-a-long-random-value
OPS_ADMIN_PASSWORD=change-this-admin-password
```

4. Click **Run**.
5. Open `/ops/login`.

If Replit asks for a run command, use:

```bash
python app.py
```

## Local run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export SESSION_SECRET="change-this-before-live"
export OPS_ADMIN_PASSWORD="change-this-admin-password"
python app.py
```

Open:

```text
http://localhost:5000/ops/login
```

## Storage note

This starter version uses JSON/local files so it can run cheaply. When AMH grows, upgrade to PostgreSQL and cloud storage/Google Drive integration.

## Before staff use

- Change `SESSION_SECRET`
- Change `OPS_ADMIN_PASSWORD`
- Test every role login/logout
- Test task creation, task notes, file upload, profile update, and admin changes
- Keep regular backups of the `data` folder

## Known limitation

This is a lean internal MVP. It is built to start operations, not to replace a full enterprise ERP on day one. Google Drive, Gmail, Outlook, WhatsApp, payments, and live collaboration are structured as future integrations.
