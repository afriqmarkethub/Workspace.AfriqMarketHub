"""AfriqMarketHub Staff Workspace — production-ready private MVP.

Entry point for the Flask application. Keep business routes in ops.py.
"""
import logging
import os
from flask import Flask, redirect, request
from werkzeug.middleware.proxy_fix import ProxyFix
from ops import ops_bp


class Config:
    APP_NAME = "AfriqMarketHub Staff Workspace"
    SECRET_KEY = os.environ.get("SESSION_SECRET") or os.environ.get("SECRET_KEY")
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.environ.get("FLASK_ENV") == "production"
    PERMANENT_SESSION_LIFETIME = int(os.environ.get("SESSION_LIFETIME_SECONDS", "28800"))
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    if not app.config["SECRET_KEY"]:
        # Safe fallback for local development only.
        app.config["SECRET_KEY"] = "dev-only-change-before-live"
        app.logger.warning("SESSION_SECRET is not set. Add it before live deployment.")

    # Required when deployed behind Render/Railway/Replit proxies.
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)

    logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"))

    app.register_blueprint(ops_bp)

    @app.after_request
    def add_security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        # Keep CSP permissive enough for current Google Fonts + inline template styles.
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "img-src 'self' data:; "
            "connect-src 'self'; "
            "frame-ancestors 'none'"
        )
        return response

    @app.route("/")
    def home():
        return redirect("/ops/login")

    @app.route("/health")
    def health():
        return {
            "status": "ok",
            "app": app.config["APP_NAME"],
            "environment": os.environ.get("FLASK_ENV", "development"),
        }

    @app.route("/robots.txt")
    def robots():
        return "User-agent: *\nDisallow: /\n", 200, {"Content-Type": "text/plain"}

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
