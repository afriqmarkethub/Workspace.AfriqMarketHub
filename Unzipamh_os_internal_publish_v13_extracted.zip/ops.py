"""
AMH Internal Ops — Employee Workstation & Task Management
Project 2: Internal operations platform for AMH e-commerce staff.
Any employee can create and assign tasks to any other role.
"""
from flask import Blueprint, render_template, session, redirect, url_for, request, jsonify, flash, abort
from datetime import date, datetime
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from functools import wraps
import uuid, os, secrets as _secrets, re, json
from pathlib import Path

ops_bp = Blueprint("ops", __name__, url_prefix="/ops")

# ── ROLES (mutable — admin can add/remove/edit) ────────────────────
# password_hash: None = no password required to log in as this role
OPS_ROLES = [
    {"id":"exec1",  "name":"Executive (CEO)",       "dept":"Executive Office",   "avatar":"CE","color":"#4f46e5","bg":"#eef2ff","password_hash":generate_password_hash("1001")},
    {"id":"exec2",  "name":"Executive (COO)",       "dept":"Executive Office",   "avatar":"CO","color":"#7c3aed","bg":"#ede9fe","password_hash":generate_password_hash("1002")},
    {"id":"ops",    "name":"Operations Manager",    "dept":"Operations",         "avatar":"OP","color":"#0891b2","bg":"#e0f2fe","password_hash":generate_password_hash("2001")},
    {"id":"logi",   "name":"Delivery & Fulfilment", "dept":"Supply Chain",       "avatar":"DF","color":"#0d9488","bg":"#ccfbf1","password_hash":generate_password_hash("3001")},
    {"id":"cs",     "name":"Customer Care",         "dept":"Support Centre",     "avatar":"CC","color":"#db2777","bg":"#fce7f3","password_hash":generate_password_hash("4001")},
    {"id":"copy",   "name":"Copywriter",            "dept":"Content & Brand",    "avatar":"CW","color":"#d97706","bg":"#fef3c7","password_hash":generate_password_hash("5001")},
    {"id":"hr",     "name":"HR & Admin",            "dept":"Human Resources",    "avatar":"HR","color":"#059669","bg":"#d1fae5","password_hash":generate_password_hash("6001")},
    {"id":"finance","name":"Finance",               "dept":"Finance & Treasury", "avatar":"FN","color":"#c2410c","bg":"#ffedd5","password_hash":generate_password_hash("7001")},
]

def get_role(rid):
    return next((r for r in OPS_ROLES if r["id"] == rid), None)

# ── DATA STORES (JSON-backed for today's private live MVP) ─────────
# This keeps your live workspace usable today without losing tasks on small code edits.
# For a larger public launch, upgrade this layer to PostgreSQL.
DATA_DIR = Path(os.environ.get("AMH_DATA_DIR", Path(__file__).resolve().parent / "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DATA_FILE = DATA_DIR / "workspace_state.json"
AUDIT_FILE = DATA_DIR / "audit.log"

_TASKS        = [
    {
        "id": "TSK-001",
        "title": "Confirm today's vendor onboarding queue",
        "desc": "Review pending vendor applications, missing documents, and approval blockers. Update the task comments with the current status before end of day.",
        "assigned_to": ["ops", "cs"],
        "created_by": "exec1",
        "priority": "high",
        "status": "todo",
        "due": "Today",
        "dept": "Vendor Operations",
        "tags": ["vendor", "onboarding", "daily ops"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-002",
        "title": "Publish daily staff operations update",
        "desc": "Prepare one clear internal update covering priorities, blockers, vendor issues, customer issues, and approved next actions.",
        "assigned_to": ["copy", "hr"],
        "created_by": "exec1",
        "priority": "medium",
        "status": "todo",
        "due": "Today",
        "dept": "Internal Communications",
        "tags": ["announcement", "communication"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-003",
        "title": "Review open delivery and fulfilment issues",
        "desc": "Check pending dispatches, delayed orders, failed delivery notes, and items requiring escalation to management.",
        "assigned_to": ["logi", "ops"],
        "created_by": "exec2",
        "priority": "high",
        "status": "in_progress",
        "due": "Today",
        "dept": "Delivery & Fulfilment",
        "tags": ["delivery", "dispatch", "escalation"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },

    {
        "id": "TSK-004",
        "title": "Process Apex Supply Co. invoice #4821",
        "desc": "Vendor portal daily task sheet: invoice is overdue. Confirm amount, attach proof, and escalate to Finance if payment remains unresolved.",
        "assigned_to": ["finance", "ops"],
        "created_by": "exec1",
        "priority": "high",
        "status": "todo",
        "due": "Overdue",
        "dept": "Vendor Finance",
        "tags": ["vendor", "invoice", "overdue"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-005",
        "title": "Approve Meridian Goods onboarding documents",
        "desc": "Review Meridian Goods vendor documents and mark missing items before approval. Use this as the standard vendor onboarding handoff record.",
        "assigned_to": ["ops", "hr"],
        "created_by": "exec1",
        "priority": "high",
        "status": "todo",
        "due": "Today",
        "dept": "Vendor Onboarding",
        "tags": ["vendor", "onboarding", "documents"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-006",
        "title": "Quality review: Apex Supply batch #18",
        "desc": "Complete QC review for Apex Supply batch #18. Record defects, photos required, accepted quantity, rejected quantity, and next action.",
        "assigned_to": ["ops", "logi"],
        "created_by": "exec2",
        "priority": "medium",
        "status": "todo",
        "due": "Today",
        "dept": "Quality Control",
        "tags": ["vendor", "qc", "batch review"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-007",
        "title": "Weekly vendor performance report",
        "desc": "Prepare vendor scorecard summary covering invoices, contracts, onboarding, quality review, delivery performance, and open risks.",
        "assigned_to": ["ops", "finance"],
        "created_by": "exec1",
        "priority": "low",
        "status": "todo",
        "due": "This Week",
        "dept": "Vendor Performance",
        "tags": ["vendor", "report", "scorecard"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-008",
        "title": "Daily work mode check-in for remote and office staff",
        "desc": "Every staff member must check in with work mode, location, device/internet readiness, and top focus. This supports remote work, physical office work, and field operations.",
        "assigned_to": ["hr", "ops"],
        "created_by": "exec1",
        "priority": "high",
        "status": "todo",
        "due": "Daily",
        "dept": "Workforce Operations",
        "tags": ["attendance", "remote work", "office"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-009",
        "title": "End-of-day handoff and blocker report",
        "desc": "Before logout, each staff member should record completed work, blockers, next action, and who can cover if unavailable.",
        "assigned_to": ["hr", "ops", "cs", "copy", "finance", "logi"],
        "created_by": "exec2",
        "priority": "medium",
        "status": "todo",
        "due": "Daily",
        "dept": "Remote Office Control",
        "tags": ["handoff", "accountability", "daily ops"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-010",
        "title": "Set Nigeria shipping zones and courier comparison rules",
        "desc": "Configure Lagos, nearby states, mid-distance, and far-distance delivery rules. Compare contract couriers, quick delivery, GIG, Kwik, Sendbox, and local dispatch options before selecting shipping price.",
        "assigned_to": ["logi", "finance", "ops"],
        "created_by": "exec2",
        "priority": "high",
        "status": "todo",
        "due": "This Week",
        "dept": "Logistics Pricing",
        "tags": ["nigeria", "shipping", "courier", "pricing"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-011",
        "title": "Build packing slip and product tracking checklist",
        "desc": "Packing slip must include order ID, SKU, vendor, QC, packaging, courier pickup, QR/tracking number, proof of delivery, and chain of custody to reduce lost packages.",
        "assigned_to": ["ops", "logi"],
        "created_by": "exec1",
        "priority": "high",
        "status": "todo",
        "due": "This Week",
        "dept": "Fulfilment Control",
        "tags": ["tracking", "packing slip", "lost packages"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-012",
        "title": "Create maintenance request workflow for Website, CRM, and Vendor Portal",
        "desc": "Staff report issues internally. Super Admin/Operations reviews and sanitizes before escalating to the external developer. Developer must not see staff operations or sensitive company data.",
        "assigned_to": ["ops", "exec1"],
        "created_by": "exec1",
        "priority": "medium",
        "status": "todo",
        "due": "This Week",
        "dept": "Maintenance Control",
        "tags": ["developer", "maintenance", "bug report", "privacy"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
    {
        "id": "TSK-013",
        "title": "Configure fee engine: platform, QC, vendor, commission, forex",
        "desc": "Keep fees configurable so AMH can add platform fees, QC fees, vendor fees, courier commissions, and category commissions later without needing developer code changes.",
        "assigned_to": ["finance", "exec1", "exec2"],
        "created_by": "exec1",
        "priority": "high",
        "status": "todo",
        "due": "This Week",
        "dept": "Revenue Engine",
        "tags": ["fees", "forex", "commission", "pricing"],
        "comments": [],
        "created_at": date.today().strftime("%b %-d"),
    },
]
ANNOUNCEMENTS = [

    {
        "id": 3,
        "title": "Vendor operations daily sheet added",
        "body": "Vendor work should now be tracked with clear priority groups: overdue invoices, contract renewals, onboarding documents, quality reviews, and weekly vendor performance reporting.",
        "author": "Operations",
        "date": date.today().strftime("%b %-d"),
        "type": "update",
        "pinned": True,
    },    {
        "id": 1,
        "title": "Private Staff Workspace is live",
        "body": "Use this workspace for tasks, announcements, leave requests, vendor operations, delivery follow-up, and internal coordination. Do not upload payment, bank, or sensitive customer data until the next security upgrade is completed.",
        "author": "AMH Admin",
        "date": date.today().strftime("%b %-d"),
        "type": "policy",
        "pinned": True,
    },
    {
        "id": 2,
        "title": "Daily operation rule",
        "body": "Every open issue must have an owner, status, due date, and next action. If a staff member is unavailable, another team member should be able to continue from the task record.",
        "author": "Operations",
        "date": date.today().strftime("%b %-d"),
        "type": "update",
        "pinned": True,
    },
]
VENDOR_STAFF = [
    {
        "id": "VS-0001",
        "vendor": "Apex Supply Co.",
        "name": "Sample Runner",
        "phone": "+2348000000000",
        "job_title": "Runner",
        "pin_hash": generate_password_hash("1234"),
        "status": "active",
        "created_at": date.today().isoformat(),
    }
]

VENDOR_MESSAGES = [
    {
        "id": "VMSG-0001",
        "staff_id": "VS-0001",
        "vendor": "Apex Supply Co.",
        "name": "Sample Runner",
        "phone": "+2348000000000",
        "message": "Sample: Store visit completed. New stock photos are ready for review.",
        "reply": "",
        "status": "open",
        "created_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }
]

EXTERNAL_PARTNERS = [
    {
        "id": "TP-0001",
        "company": "Sample Website Support Partner",
        "visible_name": "AMH Technical Support",
        "service": "Website / CRM / Vendor Portal Maintenance",
        "manager": "Sample Partner Manager",
        "phone": "+2348000000001",
        "access_level": "Assigned tickets only - staging environment",
        "status": "active",
        "notes": "Normal staff never see this company name. Work appears as AMH Technical Support.",
        "created_at": date.today().isoformat(),
        "reps": [
            {"name": "Sample Developer Rep", "role": "Representative", "phone": "+2348000000002", "status": "active"}
        ],
    }
]

LEAVE_REQUESTS = []
ATTENDANCE    = []

# ── USER PROFILE + FILE STORE ─────────────────────────────────────
PROFILES = {}
FILES = []
UPLOAD_DIR = DATA_DIR / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
ALLOWED_FILE_EXTENSIONS = {"pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "png", "jpg", "jpeg", "webp", "txt", "csv"}

def _default_email_for(rid):
    safe = re.sub(r"[^a-z0-9]+", ".", str(rid).lower()).strip(".") or "staff"
    return f"{safe}@afriqmarkethub.com"

def _profile_for(rid, role=None):
    base = PROFILES.get(rid, {}) if isinstance(PROFILES, dict) else {}
    if not isinstance(base, dict):
        base = {}
    contact = base.get("contact", {}) if isinstance(base.get("contact", {}), dict) else {}
    email = contact.get("company_email") or _default_email_for(rid)
    phone = contact.get("phone", "")
    fax = contact.get("fax", "")
    visible = contact.get("visible", ["company_email"])
    if not isinstance(visible, list):
        visible = ["company_email"]
    # At least one approved contact method must be visible when a role is contactable.
    available = {"company_email": email, "phone": phone, "fax": fax}
    if not any(available.get(k) for k in visible):
        visible = ["company_email"]
    public_contact = []
    labels = {"company_email": "Email", "phone": "Phone", "fax": "Fax"}
    for k in ("company_email", "phone", "fax"):
        if k in visible and available.get(k):
            public_contact.append({"label": labels[k], "value": available[k]})
    return {
        "display_name": base.get("display_name") or (role or {}).get("name", ""),
        "motto": base.get("motto", ""),
        "photo_url": base.get("photo_url", ""),
        "contact": {"company_email": email, "phone": phone, "fax": fax, "visible": visible, "public": public_contact},
    }

def _profiles_map():
    return {r["id"]: _profile_for(r["id"], r) for r in OPS_ROLES}

def _file_allowed(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_FILE_EXTENSIONS

def _files_for_role(rid):
    return [f for f in FILES if f.get("owner_role") == rid or rid in f.get("visible_to", [])]

# Fresh private MVP starts with no sample operational numbers. Create work organically.
_TASKS = []
ANNOUNCEMENTS = []
VENDOR_STAFF = []
VENDOR_MESSAGES = []
EXTERNAL_PARTNERS = []

def _public_roles():
    return [{k: v for k, v in r.items()} for r in OPS_ROLES]

def _audit(action, actor="system", detail=""):
    line = json.dumps({
        "time": datetime.utcnow().isoformat(timespec="seconds") + "Z",
        "actor": actor,
        "action": action,
        "detail": detail,
    })
    with AUDIT_FILE.open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")

def _read_audit(limit=30):
    """Return recent audit events newest-first for Super Admin oversight."""
    if not AUDIT_FILE.exists():
        return []
    rows = []
    try:
        for line in AUDIT_FILE.read_text(encoding="utf-8").splitlines()[-limit:]:
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
    except Exception:
        return []
    return list(reversed(rows))

def _save_state():
    payload = {
        "roles": _public_roles(),
        "tasks": _TASKS,
        "announcements": ANNOUNCEMENTS,
        "leave_requests": LEAVE_REQUESTS,
        "attendance": ATTENDANCE,
        "vendor_staff": VENDOR_STAFF,
        "vendor_messages": VENDOR_MESSAGES,
        "external_partners": EXTERNAL_PARTNERS,
        "profiles": PROFILES,
        "files": FILES,
        "saved_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }
    tmp = DATA_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    tmp.replace(DATA_FILE)

def _load_state():
    global OPS_ROLES, _TASKS, ANNOUNCEMENTS, LEAVE_REQUESTS, ATTENDANCE, VENDOR_STAFF, VENDOR_MESSAGES, EXTERNAL_PARTNERS, PROFILES, FILES
    if not DATA_FILE.exists():
        _save_state()
        return
    try:
        payload = json.loads(DATA_FILE.read_text(encoding="utf-8"))
        if isinstance(payload.get("roles"), list) and payload["roles"]:
            OPS_ROLES = payload["roles"]
        _TASKS = payload.get("tasks", []) if isinstance(payload.get("tasks", []), list) else []
        ANNOUNCEMENTS = payload.get("announcements", []) if isinstance(payload.get("announcements", []), list) else []
        LEAVE_REQUESTS = payload.get("leave_requests", []) if isinstance(payload.get("leave_requests", []), list) else []
        ATTENDANCE = payload.get("attendance", []) if isinstance(payload.get("attendance", []), list) else []
        VENDOR_STAFF = payload.get("vendor_staff", []) if isinstance(payload.get("vendor_staff", []), list) else []
        VENDOR_MESSAGES = payload.get("vendor_messages", []) if isinstance(payload.get("vendor_messages", []), list) else []
        EXTERNAL_PARTNERS = payload.get("external_partners", EXTERNAL_PARTNERS) if isinstance(payload.get("external_partners", []), list) else EXTERNAL_PARTNERS
        PROFILES = payload.get("profiles", {}) if isinstance(payload.get("profiles", {}), dict) else {}
        FILES = payload.get("files", []) if isinstance(payload.get("files", []), list) else []
    except Exception as exc:
        _audit("state_load_failed", "system", str(exc))

_load_state()

# ── SUPERUSER ADMIN ────────────────────────────────────────────────
# To change the default password, set OPS_ADMIN_PASSWORD in Replit Secrets
# or edit the fallback string below directly.
_ADMIN_CREDS = {
    "username": "amhadmin",
    "password_hash": generate_password_hash(os.environ.get("OPS_ADMIN_PASSWORD", "AMH@2024!")),
}

def _csrf_token():
    """Return (and lazily create) a per-session CSRF token."""
    if "csrf_token" not in session:
        session["csrf_token"] = _secrets.token_hex(32)
    return session["csrf_token"]

def _check_csrf():
    token = request.form.get("csrf_token", "")
    if not token or token != session.get("csrf_token"):
        abort(403)

def require_admin(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("ops_admin"):
            return redirect(url_for("ops.admin_login"))
        if request.method in ("POST", "PUT", "PATCH", "DELETE"):
            _check_csrf()
        return f(*args, **kwargs)
    return decorated

# ── HELPERS ────────────────────────────────────────────────────────
STATUS_ORDER  = ["todo","in_progress","review","done"]
STATUS_LABELS = {"todo":"To Do","in_progress":"In Progress","review":"In Review","done":"Done"}
PRIORITY_ORDER = {"high":0,"medium":1,"low":2}

def tasks_for_role(rid):
    return [t for t in _TASKS if rid in t["assigned_to"]]

def all_tasks():
    return list(_TASKS)

# ── ROUTES ─────────────────────────────────────────────────────────
@ops_bp.route("/")
def index():
    if session.get("ops_role"):
        return redirect(url_for("ops.dashboard"))
    return redirect(url_for("ops.login"))

@ops_bp.route("/login", methods=["GET","POST"])
def login():
    password_protected = [r["id"] for r in OPS_ROLES if r.get("password_hash")]
    tok = _csrf_token()
    if request.method == "POST":
        # CSRF check for login form
        submitted = request.form.get("csrf_token", "")
        if not submitted or submitted != session.get("csrf_token"):
            abort(403)
        rid  = request.form.get("role_id","")
        role = get_role(rid)
        if role:
            if role.get("password_hash"):
                pw = request.form.get("password","")
                if not re.fullmatch(r'\d{4}', pw) or not check_password_hash(role["password_hash"], pw):
                    return render_template("ops/login.html", roles=OPS_ROLES,
                                           password_protected=password_protected,
                                           error_role=rid,
                                           error="Incorrect PIN. Please try again.",
                                           csrf_token=tok)
            session["ops_role"] = rid
            _audit("staff_login", rid, request.headers.get("User-Agent", "")[:180])
            return redirect(url_for("ops.dashboard"))
    return render_template("ops/login.html", roles=OPS_ROLES,
                           password_protected=password_protected,
                           error_role=None, error=None,
                           csrf_token=tok)

@ops_bp.route("/dashboard")
def dashboard():
    rid  = session.get("ops_role")
    role = get_role(rid) if rid else None
    if not role:
        session.pop("ops_role", None)
        return redirect(url_for("ops.login"))

    my_tasks   = sorted(tasks_for_role(rid), key=lambda t: (PRIORITY_ORDER.get(t["priority"],9), t["due"]))
    all_t      = all_tasks()
    kanban     = {s: [t for t in all_t if t["status"]==s] for s in STATUS_ORDER}
    today      = date.today().strftime("%A, %B %-d, %Y")
    done_count = sum(1 for t in my_tasks if t["status"]=="done")
    open_count = sum(1 for t in my_tasks if t["status"]!="done")
    high_count = sum(1 for t in my_tasks if t["priority"]=="high" and t["status"]!="done")
    total_open = sum(1 for t in all_t if t["status"]!="done")
    active_work_log = next((a for a in reversed(ATTENDANCE) if a.get("role") == rid and a.get("status") == "active"), None)
    today_logs = [a for a in ATTENDANCE if a.get("date") == date.today().isoformat()]
    active_staff_count = sum(1 for a in today_logs if a.get("status") == "active")

    role_tasks = {}
    role_open  = {}
    for r in OPS_ROLES:
        r_t = [t for t in all_t if r["id"] in t.get("assigned_to", [])]
        role_tasks[r["id"]] = r_t
        role_open[r["id"]]  = sum(1 for t in r_t if t["status"] != "done")

    profile = _profile_for(rid, role)
    files_for_role = _files_for_role(rid)

    return render_template("ops/dashboard.html",
        role=role, roles=OPS_ROLES, today=today, profile=profile, profiles_map=_profiles_map(), files_for_role=files_for_role,
        my_tasks=my_tasks, all_tasks=all_t, kanban=kanban,
        status_labels=STATUS_LABELS, status_order=STATUS_ORDER,
        done_count=done_count, open_count=open_count,
        high_count=high_count, total_open=total_open,
        announcements=ANNOUNCEMENTS, leave_requests=LEAVE_REQUESTS,
        attendance=ATTENDANCE, active_work_log=active_work_log,
        today_logs=today_logs, active_staff_count=active_staff_count,
        role_open=role_open, role_tasks=role_tasks,
        vendor_staff=VENDOR_STAFF, vendor_messages=VENDOR_MESSAGES,
        csrf_token=_csrf_token(),
    )

@ops_bp.route("/task/create", methods=["POST"])
def task_create():
    rid = session.get("ops_role")
    if not rid:
        return redirect(url_for("ops.login"))
    _check_csrf()
    f = request.form
    assignees = request.form.getlist("assigned_to")
    if not assignees:
        assignees = [rid]
    task_id = "TSK-" + str(len(_TASKS) + 1).zfill(3)
    _TASKS.append({
        "id": task_id,
        "title":       f.get("title","Untitled Task"),
        "desc":        f.get("desc",""),
        "assigned_to": assignees,
        "created_by":  rid,
        "priority":    f.get("priority","medium"),
        "status":      "todo",
        "due":         f.get("due","TBD"),
        "dept":        f.get("dept","General"),
        "tags":        [t.strip() for t in f.get("tags","").split(",") if t.strip()],
        "comments":    [],
        "collaborators": assignees,
        "requires_approval": bool(f.get("requires_approval")),
        "attachments": [],
        "created_at":  date.today().strftime("%b %-d"),
    })
    _save_state()
    _audit("task_created", rid, task_id)
    return redirect(url_for("ops.dashboard") + "?panel=board&created=" + task_id)

@ops_bp.route("/task/<task_id>/status", methods=["POST"])
def task_status(task_id):
    rid = session.get("ops_role")
    if not rid:
        return jsonify({"error":"not logged in"}), 401
    _check_csrf()
    direction = request.form.get("direction","next")
    task = next((t for t in _TASKS if t["id"]==task_id), None)
    if task:
        idx = STATUS_ORDER.index(task["status"]) if task["status"] in STATUS_ORDER else 0
        idx = min(idx+1, len(STATUS_ORDER)-1) if direction=="next" else max(idx-1, 0)
        task["status"] = STATUS_ORDER[idx]
        _save_state()
        _audit("task_status_changed", rid, f"{task_id}:{task['status']}")
    return redirect(url_for("ops.dashboard"))

@ops_bp.route("/task/<task_id>/comment", methods=["POST"])
def task_comment(task_id):
    rid  = session.get("ops_role")
    role = get_role(rid)
    if not rid or not role:
        return redirect(url_for("ops.login"))
    _check_csrf()
    text = request.form.get("comment","").strip()
    task = next((t for t in _TASKS if t["id"]==task_id), None)
    if task and text:
        task["comments"].append({
            "author": role["name"],
            "color":  role["color"],
            "avatar": role["avatar"],
            "text":   text,
            "time":   datetime.now().strftime("%b %-d, %H:%M"),
        })
        _save_state()
        _audit("task_comment_added", rid, task_id)
    return redirect(url_for("ops.dashboard") + f"?panel=board&focus={task_id}")


@ops_bp.route("/workmode/checkin", methods=["POST"])
def workmode_checkin():
    rid  = session.get("ops_role")
    role = get_role(rid)
    if not rid or not role:
        return redirect(url_for("ops.login"))
    _check_csrf()
    f = request.form
    # Close any previous active record for this staff member before creating a new one.
    for row in ATTENDANCE:
        if row.get("role") == rid and row.get("status") == "active":
            row["status"] = "closed"
            row["closed_by"] = "new_checkin"
            row["checkout_time"] = datetime.now().strftime("%H:%M")
    log_id = "WRK-" + str(len(ATTENDANCE) + 1).zfill(4)
    ATTENDANCE.append({
        "id": log_id,
        "staff": role["name"],
        "role": rid,
        "date": date.today().isoformat(),
        "checkin_time": datetime.now().strftime("%H:%M"),
        "checkout_time": "",
        "mode": f.get("mode", "remote"),
        "location": f.get("location", ""),
        "shift": f.get("shift", "day"),
        "device_status": f.get("device_status", "ready"),
        "internet_status": f.get("internet_status", "ready"),
        "focus": f.get("focus", ""),
        "handoff": "",
        "status": "active",
    })
    _save_state()
    _audit("workmode_checkin", rid, log_id)
    return redirect(url_for("ops.dashboard") + "?panel=workstation")

@ops_bp.route("/workmode/checkout", methods=["POST"])
def workmode_checkout():
    rid = session.get("ops_role")
    if not rid:
        return redirect(url_for("ops.login"))
    _check_csrf()
    handoff = request.form.get("handoff", "").strip()
    completed = request.form.get("completed", "").strip()
    row = next((a for a in reversed(ATTENDANCE) if a.get("role") == rid and a.get("status") == "active"), None)
    if row:
        row["status"] = "closed"
        row["checkout_time"] = datetime.now().strftime("%H:%M")
        row["handoff"] = handoff
        row["completed"] = completed
        _save_state()
        _audit("workmode_checkout", rid, row.get("id", ""))
    return redirect(url_for("ops.logout"))

@ops_bp.route("/leave/request", methods=["POST"])
def leave_request():
    rid  = session.get("ops_role")
    role = get_role(rid)
    if not rid or not role:
        return redirect(url_for("ops.login"))
    _check_csrf()
    f = request.form
    leave_id = "LV-" + str(len(LEAVE_REQUESTS)+1).zfill(3)
    LEAVE_REQUESTS.append({
        "id":     leave_id,
        "staff":  role["name"], "role": rid,
        "type":   f.get("type","Annual Leave"),
        "days":   f.get("days",1),
        "from":   f.get("from_date",""),
        "to":     f.get("to_date",""),
        "status": "pending",
        "reason": f.get("reason",""),
    })
    _save_state()
    _audit("leave_requested", rid, leave_id)
    return redirect(url_for("ops.dashboard") + "?panel=hr")

@ops_bp.route("/leave/<leave_id>/approve", methods=["POST"])
def leave_approve(leave_id):
    rid = session.get("ops_role")
    if rid not in ("hr","exec1","exec2"):
        return redirect(url_for("ops.dashboard"))
    _check_csrf()
    action = request.form.get("action","approve")
    lr = next((r for r in LEAVE_REQUESTS if r["id"]==leave_id), None)
    if lr:
        lr["status"] = "approved" if action=="approve" else "declined"
        _save_state()
        _audit("leave_status_changed", rid, f"{leave_id}:{lr['status']}")
    return redirect(url_for("ops.dashboard") + "?panel=hr")


@ops_bp.route("/profile/update", methods=["POST"])
def profile_update():
    rid = session.get("ops_role")
    role = get_role(rid) if rid else None
    if not rid or not role:
        return redirect(url_for("ops.login"))
    _check_csrf()
    profile = PROFILES.setdefault(rid, {})
    display_name = request.form.get("display_name", "").strip()[:80]
    motto = request.form.get("motto", "").strip()[:120]
    if display_name:
        profile["display_name"] = display_name
    profile["motto"] = motto
    contact = profile.setdefault("contact", {})
    contact["company_email"] = request.form.get("company_email", "").strip()[:120] or contact.get("company_email") or _default_email_for(rid)
    contact["phone"] = request.form.get("phone", "").strip()[:40]
    contact["fax"] = request.form.get("fax", "").strip()[:40]
    visible = request.form.getlist("visible_contact")
    if not visible:
        # If user hides everything, keep one approved method visible by default.
        visible = ["company_email"]
    contact["visible"] = [x for x in visible if x in {"company_email", "phone", "fax"}] or ["company_email"]
    photo = request.files.get("photo")
    if photo and photo.filename:
        filename = secure_filename(photo.filename)
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        if ext in {"png", "jpg", "jpeg", "webp"}:
            safe = f"profile_{rid}_{uuid.uuid4().hex[:8]}.{ext}"
            photo.save(UPLOAD_DIR / safe)
            profile["photo_url"] = url_for("ops.uploaded_file", filename=safe)
    _save_state()
    _audit("profile_updated", rid, "profile")
    return redirect(url_for("ops.dashboard") + "?panel=settings")

@ops_bp.route("/uploads/<path:filename>")
def uploaded_file(filename):
    from flask import send_from_directory
    return send_from_directory(UPLOAD_DIR, filename, as_attachment=False)

@ops_bp.route("/file/upload", methods=["POST"])
def file_upload():
    rid = session.get("ops_role")
    role = get_role(rid) if rid else None
    if not rid or not role:
        return redirect(url_for("ops.login"))
    _check_csrf()
    f = request.files.get("file")
    if not f or not f.filename or not _file_allowed(f.filename):
        flash("Upload a supported file type.", "error")
        return redirect(url_for("ops.dashboard") + "?panel=files")
    original = secure_filename(f.filename)
    ext = original.rsplit(".",1)[-1].lower()
    stored = f"file_{uuid.uuid4().hex}.{ext}"
    f.save(UPLOAD_DIR / stored)
    task_id = request.form.get("task_id", "").strip()
    rec = {
        "id": "FILE-" + str(len(FILES)+1).zfill(4),
        "name": original,
        "kind": ext.upper(),
        "stored": stored,
        "url": url_for("ops.uploaded_file", filename=stored),
        "owner_role": rid,
        "owner_name": role["name"],
        "task_id": task_id,
        "note": request.form.get("note", "").strip(),
        "visible_to": [rid],
        "created_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }
    FILES.insert(0, rec)
    if task_id:
        t = next((x for x in _TASKS if x.get("id") == task_id), None)
        if t is not None:
            t.setdefault("attachments", []).append(rec["id"])
            if rid not in t.get("assigned_to", []):
                rec["visible_to"].extend(t.get("assigned_to", []))
    _save_state()
    _audit("file_uploaded", rid, rec["id"])
    return redirect(url_for("ops.dashboard") + "?panel=files")

@ops_bp.route("/file/create", methods=["POST"])
def file_create():
    rid = session.get("ops_role")
    role = get_role(rid) if rid else None
    if not rid or not role:
        return redirect(url_for("ops.login"))
    _check_csrf()
    kind = request.form.get("kind", "Document").strip()[:40]
    title = request.form.get("title", "Untitled").strip()[:120]
    task_id = request.form.get("task_id", "").strip()
    rec = {
        "id": "FILE-" + str(len(FILES)+1).zfill(4),
        "name": title,
        "kind": kind,
        "stored": "",
        "url": "#",
        "owner_role": rid,
        "owner_name": role["name"],
        "task_id": task_id,
        "note": "Created from AMH OS",
        "visible_to": [rid],
        "created_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }
    FILES.insert(0, rec)
    _save_state()
    _audit("office_file_created", rid, rec["id"])
    return redirect(url_for("ops.dashboard") + "?panel=files")

@ops_bp.route("/vendor-staff/create", methods=["POST"])
def vendor_staff_create():
    rid = session.get("ops_role")
    if not rid:
        return redirect(url_for("ops.login"))
    _check_csrf()
    f = request.form
    name = f.get("name", "").strip()
    phone = f.get("phone", "").strip()
    vendor = f.get("vendor", "").strip()
    pin = f.get("pin", "").strip()
    if not name or not phone or not vendor or not re.fullmatch(r"\d{4}", pin):
        flash("Vendor staff requires name, phone, vendor, and a 4-digit PIN.", "error")
        return redirect(url_for("ops.dashboard") + "?panel=vendor-comms")
    if any(x.get("phone") == phone and x.get("vendor", "").lower() == vendor.lower() for x in VENDOR_STAFF):
        flash("That vendor staff phone number already exists for this vendor.", "error")
        return redirect(url_for("ops.dashboard") + "?panel=vendor-comms")
    staff_id = "VS-" + str(len(VENDOR_STAFF) + 1).zfill(4)
    VENDOR_STAFF.append({
        "id": staff_id,
        "vendor": vendor,
        "name": name,
        "phone": phone,
        "job_title": f.get("job_title", "Field Staff").strip() or "Field Staff",
        "pin_hash": generate_password_hash(pin),
        "status": "active",
        "created_at": date.today().isoformat(),
    })
    _save_state()
    _audit("vendor_staff_created", rid, f"{staff_id}:{vendor}:{phone}")
    return redirect(url_for("ops.dashboard") + "?panel=vendor-comms")

@ops_bp.route("/vendor-staff/<staff_id>/block", methods=["POST"])
def vendor_staff_block(staff_id):
    rid = session.get("ops_role")
    if not rid:
        return redirect(url_for("ops.login"))
    _check_csrf()
    reason = request.form.get("reason", "Blocked by AMH or vendor request").strip()
    staff = next((x for x in VENDOR_STAFF if x.get("id") == staff_id), None)
    if staff:
        staff["status"] = "blocked"
        staff["blocked_reason"] = reason
        staff["blocked_at"] = datetime.utcnow().isoformat(timespec="seconds") + "Z"
        _save_state()
        _audit("vendor_staff_blocked", rid, f"{staff_id}:{reason}")
    return redirect(url_for("ops.dashboard") + "?panel=vendor-comms")

@ops_bp.route("/vendor-message/<msg_id>/reply", methods=["POST"])
def vendor_message_reply(msg_id):
    rid = session.get("ops_role")
    if not rid:
        return redirect(url_for("ops.login"))
    _check_csrf()
    msg = next((m for m in VENDOR_MESSAGES if m.get("id") == msg_id), None)
    if msg:
        msg["reply"] = request.form.get("reply", "").strip()
        msg["status"] = request.form.get("status", "answered")
        msg["answered_at"] = datetime.utcnow().isoformat(timespec="seconds") + "Z"
        msg["answered_by"] = rid
        _save_state()
        _audit("vendor_message_replied", rid, msg_id)
    return redirect(url_for("ops.dashboard") + "?panel=vendor-comms")

@ops_bp.route("/vendor/communication", methods=["GET", "POST"])
def vendor_communication():
    tok = _csrf_token()
    error = None
    success = None
    if request.method == "POST":
        submitted = request.form.get("csrf_token", "")
        if not submitted or submitted != session.get("csrf_token"):
            abort(403)
        phone = request.form.get("phone", "").strip()
        pin = request.form.get("pin", "").strip()
        message = request.form.get("message", "").strip()
        staff = next((x for x in VENDOR_STAFF if x.get("phone") == phone), None)
        if not staff or not check_password_hash(staff.get("pin_hash", ""), pin):
            error = "We could not verify your phone and PIN. Contact your vendor administrator or AMH Vendor Support."
        elif staff.get("status") != "active":
            error = "This access is not active. Contact your vendor administrator or AMH Vendor Support."
        elif not message:
            error = "Type your message before sending."
        elif re.search(r"(nude|violence|kill|blood|sex)", message, re.I):
            error = "Message blocked by AMH safety rules. Please send only work-related communication."
            _audit("vendor_message_safety_block", staff.get("id"), phone)
        else:
            msg_id = "VMSG-" + str(len(VENDOR_MESSAGES) + 1).zfill(4)
            VENDOR_MESSAGES.append({
                "id": msg_id,
                "staff_id": staff.get("id"),
                "vendor": staff.get("vendor"),
                "name": staff.get("name"),
                "phone": staff.get("phone"),
                "message": message,
                "reply": "",
                "status": "open",
                "created_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
            })
            _save_state()
            _audit("vendor_message_created", staff.get("id"), msg_id)
            success = "Message sent to AMH Vendor Support."
    return render_template("ops/vendor_communication.html", csrf_token=tok, error=error, success=success)

@ops_bp.route("/logout")
def logout():
    rid = session.get("ops_role")
    if rid:
        _audit("staff_logout", rid, "manual logout")
    session.pop("ops_role", None)
    return redirect(url_for("ops.login"))

# ── ADMIN ROUTES ───────────────────────────────────────────────────
@ops_bp.route("/admin/login", methods=["GET","POST"])
def admin_login():
    if session.get("ops_admin"):
        return redirect(url_for("ops.admin_dashboard"))
    error = None
    tok = _csrf_token()
    if request.method == "POST":
        submitted = request.form.get("csrf_token", "")
        if not submitted or submitted != session.get("csrf_token"):
            abort(403)
        uname = request.form.get("username","").strip()
        pw    = request.form.get("password","")
        if uname == _ADMIN_CREDS["username"] and check_password_hash(_ADMIN_CREDS["password_hash"], pw):
            ops_role = session.get("ops_role")
            session.clear()
            if ops_role:
                session["ops_role"] = ops_role
            session["ops_admin"] = True
            _csrf_token()
            _audit("admin_login", uname, "admin dashboard")
            return redirect(url_for("ops.admin_dashboard"))
        error = "Invalid credentials. Please try again."
    return render_template("ops/admin_login.html", error=error, csrf_token=tok)

@ops_bp.route("/admin/")
@require_admin
def admin_dashboard():
    total_tasks = len(_TASKS)
    open_tasks  = sum(1 for t in _TASKS if t["status"] != "done")
    high_tasks  = sum(1 for t in _TASKS if t["priority"] == "high" and t["status"] != "done")
    pinned_ann  = sum(1 for a in ANNOUNCEMENTS if a.get("pinned"))
    pending_leave = sum(1 for r in LEAVE_REQUESTS if r.get("status") == "pending")
    return render_template("ops/admin.html",
        tasks=_TASKS, announcements=ANNOUNCEMENTS, roles=OPS_ROLES,
        status_labels=STATUS_LABELS, status_order=STATUS_ORDER,
        total_tasks=total_tasks, open_tasks=open_tasks,
        high_tasks=high_tasks, pinned_ann=pinned_ann,
        leave_requests=LEAVE_REQUESTS, pending_leave=pending_leave,
        audit_rows=_read_audit(40),
        today=date.today().strftime("%A, %B %-d, %Y"),
        csrf_token=_csrf_token(),
    )

@ops_bp.route("/admin/logout", methods=["POST"])
def admin_logout():
    token = request.form.get("csrf_token","")
    if not token or token != session.get("csrf_token"):
        abort(403)
    session.pop("ops_admin", None)
    session.pop("csrf_token", None)
    return redirect(url_for("ops.admin_login"))

@ops_bp.route("/admin/view-as/<role_id>")
@require_admin
def admin_view_as(role_id):
    """Allow Super Admin to view any staff workspace while staying admin."""
    role = get_role(role_id)
    if not role:
        flash("Role not found.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#roles")
    session["ops_role"] = role_id
    _audit("admin_view_as_role", "amhadmin", role_id)
    return redirect(url_for("ops.dashboard"))

# ── Admin: Task CRUD ──
@ops_bp.route("/admin/task/create", methods=["POST"])
@require_admin
def admin_task_create():
    f = request.form
    assignees = request.form.getlist("assigned_to") or ["exec1"]
    task_id = "TSK-" + str(len(_TASKS) + 1).zfill(3)
    _TASKS.append({
        "id": task_id,
        "title":       f.get("title","Untitled Task"),
        "desc":        f.get("desc",""),
        "assigned_to": assignees,
        "created_by":  "amhadmin",
        "priority":    f.get("priority","medium"),
        "status":      "todo",
        "due":         f.get("due","TBD"),
        "dept":        f.get("dept","General"),
        "tags":        [t.strip() for t in f.get("tags","").split(",") if t.strip()],
        "comments":    [],
        "created_at":  date.today().strftime("%b %-d"),
    })
    _save_state()
    _audit("admin_task_created", "amhadmin", task_id)
    flash(f"Task {task_id} created.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#tasks")

@ops_bp.route("/admin/task/<task_id>/delete", methods=["POST"])
@require_admin
def admin_task_delete(task_id):
    global _TASKS
    before = len(_TASKS)
    _TASKS = [t for t in _TASKS if t["id"] != task_id]
    if len(_TASKS) < before:
        _save_state()
        _audit("admin_task_deleted", "amhadmin", task_id)
    flash(f"Task {task_id} deleted." if len(_TASKS) < before else f"{task_id} not found.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#tasks")

# ── Admin: Announcement CRUD ──
@ops_bp.route("/admin/announcement/create", methods=["POST"])
@require_admin
def admin_announcement_create():
    f = request.form
    new_id = max((a["id"] for a in ANNOUNCEMENTS), default=0) + 1
    ANNOUNCEMENTS.insert(0, {
        "id":     new_id,
        "title":  f.get("title","Untitled"),
        "body":   f.get("body",""),
        "author": "AMH Admin",
        "date":   date.today().strftime("%b %-d"),
        "type":   f.get("type","update"),
        "pinned": f.get("pinned") == "1",
    })
    _save_state()
    _audit("announcement_published", "amhadmin", str(new_id))
    flash("Announcement published.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#announcements")

@ops_bp.route("/admin/announcement/<int:ann_id>/delete", methods=["POST"])
@require_admin
def admin_announcement_delete(ann_id):
    before = len(ANNOUNCEMENTS)
    ANNOUNCEMENTS[:] = [a for a in ANNOUNCEMENTS if a["id"] != ann_id]
    if len(ANNOUNCEMENTS) < before:
        _save_state()
        _audit("announcement_deleted", "amhadmin", str(ann_id))
    flash("Announcement deleted." if len(ANNOUNCEMENTS) < before else "Not found.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#announcements")

# ── Admin: Role CRUD ──
@ops_bp.route("/admin/role/create", methods=["POST"])
@require_admin
def admin_role_create():
    f = request.form
    name   = f.get("name","").strip()
    dept   = f.get("dept","").strip()
    avatar = f.get("avatar","??").strip()[:2].upper()
    color  = f.get("color","#6b7280").strip()
    bg     = f.get("bg","#f3f4f6").strip()
    pin    = f.get("pin","").strip()
    pin_confirm = f.get("pin_confirm","").strip()
    if not name:
        flash("Role name is required.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#roles")
    if not re.fullmatch(r'\d{4}', pin):
        flash("Every role must have a 4-digit PIN.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#roles")
    if pin != pin_confirm:
        flash("Role PINs do not match.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#roles")
    # Build a unique, route-safe ID (only a-z, 0-9, _)
    base_id = re.sub(r'[^a-z0-9_]', '', name.lower().replace(" ","_"))[:12] or "role"
    role_id = base_id
    existing_ids = {r["id"] for r in OPS_ROLES}
    counter = 2
    while role_id in existing_ids:
        role_id = f"{base_id}{counter}"
        counter += 1
    OPS_ROLES.append({
        "id": role_id, "name": name, "dept": dept,
        "avatar": avatar, "color": color, "bg": bg,
        "password_hash": generate_password_hash(pin),
    })
    _save_state()
    _audit("role_created", "amhadmin", role_id)
    flash(f"Role '{name}' created (ID: {role_id}).", "success")
    return redirect(url_for("ops.admin_dashboard") + "#roles")

@ops_bp.route("/admin/role/<role_id>/delete", methods=["POST"])
@require_admin
def admin_role_delete(role_id):
    before = len(OPS_ROLES)
    OPS_ROLES[:] = [r for r in OPS_ROLES if r["id"] != role_id]
    if len(OPS_ROLES) < before:
        _save_state()
        _audit("role_deleted", "amhadmin", role_id)
        flash(f"Role '{role_id}' deleted.", "success")
    else:
        flash("Role not found.", "error")
    return redirect(url_for("ops.admin_dashboard") + "#roles")

@ops_bp.route("/admin/role/<role_id>/set-password", methods=["POST"])
@require_admin
def admin_role_set_password(role_id):
    role = get_role(role_id)
    if not role:
        flash("Role not found.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#roles")
    pw      = request.form.get("role_password","").strip()
    confirm = request.form.get("role_password_confirm","").strip()
    if not re.fullmatch(r'\d{4}', pw):
        flash("PIN must be exactly 4 digits (numbers only).", "error")
    elif pw != confirm:
        flash("PINs do not match.", "error")
    else:
        role["password_hash"] = generate_password_hash(pw)
        _save_state()
        _audit("role_pin_set", "amhadmin", role_id)
        flash(f"PIN set for '{role['name']}'.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#roles")

@ops_bp.route("/admin/role/<role_id>/clear-password", methods=["POST"])
@require_admin
def admin_role_clear_password(role_id):
    # Live-use safety: every staff role must remain protected by a PIN.
    flash("Role PIN removal is disabled. Change the PIN instead.", "error")
    return redirect(url_for("ops.admin_dashboard") + "#roles")


@ops_bp.route("/admin/task/<task_id>/update", methods=["POST"])
@require_admin
def admin_task_update(task_id):
    task = next((t for t in _TASKS if t["id"] == task_id), None)
    if not task:
        flash("Task not found.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#tasks")
    f = request.form
    title = f.get("title", "").strip()
    if title:
        task["title"] = title
    task["desc"] = f.get("desc", task.get("desc", ""))
    task["priority"] = f.get("priority", task.get("priority", "medium"))
    task["status"] = f.get("status", task.get("status", "todo"))
    task["due"] = f.get("due", task.get("due", "TBD"))
    task["dept"] = f.get("dept", task.get("dept", "General"))
    assignees = f.getlist("assigned_to")
    if assignees:
        valid = {r["id"] for r in OPS_ROLES}
        task["assigned_to"] = [rid for rid in assignees if rid in valid]
    _save_state()
    _audit("admin_task_updated", "amhadmin", task_id)
    flash(f"Task {task_id} updated.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#tasks")

@ops_bp.route("/admin/role/<role_id>/update", methods=["POST"])
@require_admin
def admin_role_update(role_id):
    role = get_role(role_id)
    if not role:
        flash("Role not found.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#roles")
    f = request.form
    name = f.get("name", "").strip()
    if not name:
        flash("Role name is required.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#roles")
    role["name"] = name
    role["dept"] = f.get("dept", "").strip()
    role["avatar"] = (f.get("avatar", role.get("avatar", "??")).strip()[:2] or "??").upper()
    role["color"] = f.get("color", role.get("color", "#6b7280")).strip()
    role["bg"] = f.get("bg", role.get("bg", "#f3f4f6")).strip()
    _save_state()
    _audit("role_updated", "amhadmin", role_id)
    flash(f"Role '{role['name']}' updated.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#roles")

@ops_bp.route("/admin/announcement/<int:ann_id>/update", methods=["POST"])
@require_admin
def admin_announcement_update(ann_id):
    ann = next((a for a in ANNOUNCEMENTS if a["id"] == ann_id), None)
    if not ann:
        flash("Announcement not found.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#announcements")
    f = request.form
    ann["title"] = f.get("title", ann.get("title", "Untitled")).strip() or "Untitled"
    ann["body"] = f.get("body", ann.get("body", ""))
    ann["type"] = f.get("type", ann.get("type", "update"))
    ann["pinned"] = f.get("pinned") == "1"
    _save_state()
    _audit("announcement_updated", "amhadmin", str(ann_id))
    flash("Announcement updated.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#announcements")

@ops_bp.route("/admin/leave/<leave_id>/update", methods=["POST"])
@require_admin
def admin_leave_update(leave_id):
    lr = next((r for r in LEAVE_REQUESTS if r["id"] == leave_id), None)
    if not lr:
        flash("Leave request not found.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#leave")
    status = request.form.get("status", "pending")
    if status not in ("pending", "approved", "declined"):
        status = "pending"
    lr["status"] = status
    _save_state()
    _audit("admin_leave_updated", "amhadmin", f"{leave_id}:{status}")
    flash(f"Leave request {leave_id} updated.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#leave")

# ── Admin: External Partner / Third-Party Control ──
@ops_bp.route("/admin/external-partner/create", methods=["POST"])
@require_admin
def admin_external_partner_create():
    f = request.form
    company = f.get("company", "").strip()
    service = f.get("service", "").strip()
    manager = f.get("manager", "").strip()
    phone = f.get("phone", "").strip()
    access_level = f.get("access_level", "Assigned tickets only - staging environment").strip()
    if not company or not service:
        flash("Third-party company and service are required.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#partners")
    partner_id = f"TP-{len(EXTERNAL_PARTNERS)+1:04d}"
    EXTERNAL_PARTNERS.insert(0, {
        "id": partner_id,
        "company": company,
        "visible_name": "AMH Technical Support",
        "service": service,
        "manager": manager or "Not assigned",
        "phone": phone,
        "access_level": access_level,
        "status": "active",
        "notes": f.get("notes", "Normal staff see only AMH Technical Support."),
        "created_at": date.today().isoformat(),
        "reps": [],
    })
    _save_state()
    _audit("external_partner_created", "amhadmin", partner_id)
    flash("Third-party company added. It is hidden from normal staff workspaces.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#partners")

@ops_bp.route("/admin/external-partner/<partner_id>/status", methods=["POST"])
@require_admin
def admin_external_partner_status(partner_id):
    partner = next((p for p in EXTERNAL_PARTNERS if p.get("id") == partner_id), None)
    if not partner:
        flash("Third-party company not found.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#partners")
    status = request.form.get("status", "active")
    if status not in ("active", "suspended", "deactivated"):
        status = "active"
    reason = request.form.get("reason", "").strip()
    partner["status"] = status
    if reason:
        partner["last_reason"] = reason
    _save_state()
    _audit("external_partner_status_changed", "amhadmin", f"{partner_id}:{status}:{reason}")
    flash(f"Third-party company status changed to {status}.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#partners")

@ops_bp.route("/admin/external-partner/<partner_id>/rep/add", methods=["POST"])
@require_admin
def admin_external_partner_rep_add(partner_id):
    partner = next((p for p in EXTERNAL_PARTNERS if p.get("id") == partner_id), None)
    if not partner:
        flash("Third-party company not found.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#partners")
    f = request.form
    name = f.get("name", "").strip()
    role = f.get("role", "Representative").strip()
    phone = f.get("phone", "").strip()
    if not name:
        flash("Representative name is required.", "error")
        return redirect(url_for("ops.admin_dashboard") + "#partners")
    partner.setdefault("reps", []).append({"name": name, "role": role, "phone": phone, "status": "active"})
    _save_state()
    _audit("external_partner_rep_added", "amhadmin", f"{partner_id}:{name}")
    flash("Third-party representative added.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#partners")

# ── Admin: Change admin password ──
@ops_bp.route("/admin/change-password", methods=["POST"])
@require_admin
def admin_change_password():
    current = request.form.get("current_password","")
    new_pw  = request.form.get("new_password","").strip()
    confirm = request.form.get("confirm_password","").strip()
    if not check_password_hash(_ADMIN_CREDS["password_hash"], current):
        flash("Current password is incorrect.", "error")
    elif len(new_pw) < 8:
        flash("New password must be at least 8 characters.", "error")
    elif new_pw != confirm:
        flash("Passwords do not match.", "error")
    else:
        _ADMIN_CREDS["password_hash"] = generate_password_hash(new_pw)
        flash("Admin password changed successfully.", "success")
    return redirect(url_for("ops.admin_dashboard") + "#security")
